import {writeFile} from "node:fs/promises";
import {gunzipSync} from "node:zlib";
const base=(process.argv[2]||"http://localhost:3000").replace(/\/$/,"");
const concurrency=8;
async function get(url){const r=await fetch(url,{headers:{"User-Agent":"FragmentClone-AnimationAudit/1.0"}});if(!r.ok)throw new Error(`HTTP ${r.status}`);return new Uint8Array(await r.arrayBuffer())}
async function validTgs(bytes){let raw=Buffer.from(bytes);try{raw=gunzipSync(raw)}catch{}const text=raw.toString("utf8");const j=JSON.parse(text);return !!(j.v&&j.layers&&Array.isArray(j.layers))}
async function pool(items,fn){const out=[];let i=0;await Promise.all(Array.from({length:concurrency},async()=>{while(i<items.length){const n=i++;try{out[n]={...items[n],ok:true,...await fn(items[n])}}catch(e){out[n]={...items[n],ok:false,error:String(e)}}}}));return out}
const report={base,startedAt:new Date().toISOString(),checks:[]};
console.log("Fetching live Gift Changes catalog…");
const catalog=await (await fetch(`${base}/api/gift-catalog`)).json();
if(!Array.isArray(catalog.gifts))throw new Error("Catalog endpoint did not return gifts[]");
const modelJobs=[];
for(const gift of catalog.gifts){if(gift.originalAnimation)report.checks.push({kind:"collection",gift:gift.name,url:new URL(gift.originalAnimation,base).href});for(const model of gift.models||[]){if(model.name)modelJobs.push({kind:"model",gift:gift.slug,model:model.name,url:`${base}/api/gift-model/${encodeURIComponent(gift.slug)}/${encodeURIComponent(model.name)}`})}}
console.log(`Checking ${report.checks.length} collection animations and ${modelJobs.length} model animations…`);
const collections=await pool(report.checks,async x=>({validTgs:await validTgs(await get(x.url))}));
const models=await pool(modelJobs,async x=>({validTgs:await validTgs(await get(x.url))}));
console.log("Fetching live Fragment collectible results for real NFT instance animations…");
let nftJobs=[];
try{const listings=await (await fetch(`${base}/api/fragment/search?type=collectibles`)).json();const html=String(listings.html||listings.body||"");const urls=[...html.matchAll(/(?:srcset|src)=["']([^"']+\.tgs(?:\?[^"']*)?)/gi)].map(m=>m[1].split(",")[0].trim().split(/\s+/)[0]);nftJobs=[...new Set(urls)].map(url=>({kind:"fragment-nft",url:new URL(url,base).href}))}catch(e){console.warn("Could not enumerate current Fragment NFT animation URLs:",String(e))}
const nfts=await pool(nftJobs,async x=>({validTgs:await validTgs(await get(x.url))}));
report.checks=[...collections,...models,...nfts];report.finishedAt=new Date().toISOString();report.summary={collections:{total:collections.length,passed:collections.filter(x=>x.ok&&x.validTgs).length,failed:collections.filter(x=>!x.ok||!x.validTgs).length},models:{total:models.length,passed:models.filter(x=>x.ok&&x.validTgs).length,failed:models.filter(x=>!x.ok||!x.validTgs).length},liveNftInstances:{total:nfts.length,passed:nfts.filter(x=>x.ok&&x.validTgs).length,failed:nfts.filter(x=>!x.ok||!x.validTgs).length}};
await writeFile("gift-animation-audit.json",JSON.stringify(report,null,2));
console.log(JSON.stringify(report.summary,null,2));console.log("Wrote gift-animation-audit.json");
if([...collections,...models,...nfts].some(x=>!x.ok||!x.validTgs))process.exitCode=1;
