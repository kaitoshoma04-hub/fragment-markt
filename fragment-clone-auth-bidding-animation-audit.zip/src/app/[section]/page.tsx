import {notFound} from "next/navigation";
import {FragmentLiveMarket} from "@/components/fragment-live-market";
const sections:Record<string,{title:string;desc:string;kind?:"usernames"|"numbers"|"collectibles"}>={
 usernames:{title:"Buy and Sell Usernames",desc:"Secure your Telegram username and assign it to your profile, channel or group.",kind:"usernames"},
 numbers:{title:"Anonymous Numbers",desc:"Browse collectible +888 phone numbers with live Fragment pricing.",kind:"numbers"},
 gifts:{title:"Buy and Sell Gifts",desc:"Explore Telegram collectible gifts, live listings and current Fragment prices.",kind:"collectibles"},
 auctions:{title:"Top Auctions",desc:"Live auctions and collectible listings from Fragment.",kind:"usernames"}
};
export function generateStaticParams(){return Object.keys(sections).map(section=>({section}))}
export default async function SectionPage({params}:{params:Promise<{section:string}>}){const {section}=await params;const s=sections[section];if(!s)notFound();return <section className="section shell listing fragment-section"><div className="overline">FRAGMENT / {section.toUpperCase()}</div><h1 className="page-title">{s.title}</h1><p className="page-desc">{s.desc}</p><FragmentLiveMarket kind={s.kind!}/></section>}