import {NextResponse} from "next/server";
import {getFragmentSession} from "@/lib/fragment-session";
export async function GET(){const s=await getFragmentSession();return NextResponse.json({authenticated:!!s?.stel_token,walletVerified:!!s?.stel_ton_token,walletAddress:s?.wallet_address||null,source:s?.stel_token?"fragment.com":null})}
export async function DELETE(){const {clearFragmentSession}=await import("@/lib/fragment-session");const response=NextResponse.json({ok:true});clearFragmentSession(response);return response}
