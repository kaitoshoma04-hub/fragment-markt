import {createHash,createHmac,timingSafeEqual} from "node:crypto";
import {NextRequest,NextResponse} from "next/server";
import {assertSameOrigin,fragmentInit,fragmentRpc,setFragmentSession} from "@/lib/fragment-session";
export const runtime="nodejs";
export async function POST(req:NextRequest){try{
 assertSameOrigin(req);
 const botToken=process.env.TELEGRAM_BOT_TOKEN;if(!botToken)return NextResponse.json({error:"TELEGRAM_BOT_TOKEN is not configured"},{status:503});
 const user=await req.json() as Record<string,string|number>;
 const hash=String(user.hash||"");const authDate=Number(user.auth_date||0);
 if(!hash||!authDate||Date.now()/1000-authDate>600||authDate>Date.now()/1000+30)return NextResponse.json({error:"Telegram login data expired"},{status:401});
 const check=Object.keys(user).filter(k=>k!=="hash").sort().map(k=>`${k}=${user[k]}`).join("\n");
 // Telegram Login Widget signature: HMAC-SHA256 using SHA256(bot_token) as key.
 const secret=createHash("sha256").update(botToken).digest();
 const expected=createHmac("sha256",secret).update(check).digest();
 let supplied:Buffer;try{supplied=Buffer.from(hash,"hex")}catch{return NextResponse.json({error:"Invalid Telegram hash"},{status:401})}
 if(supplied.length!==expected.length||!timingSafeEqual(supplied,expected))return NextResponse.json({error:"Invalid Telegram signature"},{status:401});
 const {hash:apiHash,cookies}=await fragmentInit();
 const auth=Buffer.from(JSON.stringify(user)).toString("base64");
 const result=await fragmentRpc(cookies,apiHash,{method:"logIn",auth});
 const response=NextResponse.json({ok:true,source:"fragment.com",user:{id:user.id,username:user.username||null}});
 setFragmentSession(response,result.cookies);return response;
 }catch(e){return NextResponse.json({error:"Fragment Telegram login failed",detail:String(e)},{status:502})}}
