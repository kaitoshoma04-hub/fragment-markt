import {NextResponse} from "next/server";
export async function POST(){return NextResponse.json({error:"Use /api/auth/fragment/telegram for a verified Fragment session."},{status:410})}
