import {NextRequest,NextResponse} from "next/server";
export const revalidate=86400;
export async function GET(_req:NextRequest,{params}:{params:Promise<{gift:string;model:string}>}){
 const {gift,model}=await params;
 const safe=(s:string)=>decodeURIComponent(s).replace(/[^a-zA-Z0-9 _-]/g,"");
 const g=safe(gift),m=safe(model);if(!g||!m)return new NextResponse("Invalid asset",{status:400});
 const upstream=await fetch(`https://api.changes.tg/model/${encodeURIComponent(g)}/${encodeURIComponent(m)}.tgs`,{next:{revalidate:86400}});
 if(!upstream.ok)return new NextResponse("Animation not available",{status:upstream.status});
 return new NextResponse(await upstream.arrayBuffer(),{headers:{"Content-Type":"application/gzip","Cache-Control":"public,max-age=86400,stale-while-revalidate=604800"}});
}