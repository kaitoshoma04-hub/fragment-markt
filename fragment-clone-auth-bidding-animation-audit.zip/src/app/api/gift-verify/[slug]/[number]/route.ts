import {NextResponse} from "next/server";
export const dynamic="force-dynamic";
const slugRx=/^[a-z0-9]{2,40}$/i;
export async function GET(_req:Request,{params}:{params:Promise<{slug:string;number:string}>}){
 const {slug,number}=await params;const id=Number(number);
 if(!slugRx.test(slug)||!Number.isSafeInteger(id)||id<1||id>1e8)return NextResponse.json({error:"Invalid gift NFT identifier"},{status:400});
 const nftSlug=`${slug}-${id}`;const urls={tgs:`https://nft.fragment.com/gift/${nftSlug}.tgs`,lottie:`https://nft.fragment.com/gift/${nftSlug}.lottie.json`,metadata:`https://t.me/nft/${nftSlug}`};
 const check=async(url:string)=>{try{const r=await fetch(url,{headers:{"User-Agent":"Mozilla/5.0"},cache:"no-store"});return {ok:r.ok,status:r.status,contentType:r.headers.get("content-type"),bytes:r.ok?(await r.arrayBuffer()).byteLength:0}}catch(e){return {ok:false,status:0,contentType:null,bytes:0,error:String(e)}}};
 const [tgs,lottie,meta]=await Promise.all([check(urls.tgs),check(urls.lottie),check(urls.metadata)]);
 let metadataText="";if(meta.ok){try{metadataText=await (await fetch(urls.metadata,{headers:{"User-Agent":"Mozilla/5.0"},cache:"no-store"})).then(r=>r.text())}catch{}}
 const desc=metadataText.match(/name=["']twitter:description["'][^>]*content=["']([^"']*)/i)?.[1]||metadataText.match(/content=["']([^"']*)["'][^>]*name=["']twitter:description/i)?.[1]||null;
 return NextResponse.json({gift:nftSlug,checkedAt:new Date().toISOString(),assets:{tgs,lottie,metadata:meta},description:desc,urls},{headers:{"Cache-Control":"no-store"}})
}
