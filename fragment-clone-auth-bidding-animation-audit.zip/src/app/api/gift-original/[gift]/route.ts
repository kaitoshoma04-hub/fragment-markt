import {NextRequest,NextResponse} from "next/server";
export const revalidate=86400;
export async function GET(_req:NextRequest,{params}:{params:Promise<{gift:string}>}){
 const {gift}=await params;const safe=decodeURIComponent(gift).replace(/[^a-zA-Z0-9 _-]/g,"");
 if(!safe)return new NextResponse("Invalid gift",{status:400});
 const r=await fetch(`https://api.changes.tg/original/${encodeURIComponent(safe)}.tgs`,{next:{revalidate:86400}});
 if(!r.ok)return new NextResponse("Gift animation unavailable",{status:r.status});
 return new NextResponse(await r.arrayBuffer(),{headers:{"Content-Type":"application/gzip","Cache-Control":"public,max-age=86400,stale-while-revalidate=604800"}});
}