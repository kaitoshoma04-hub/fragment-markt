import {NextRequest,NextResponse} from "next/server";
const allowed=new Set(["PlushPepe-1"]);
export async function GET(_req:NextRequest,{params}:{params:Promise<{gift:string}>}){
 const {gift}=await params;
 if(!allowed.has(gift))return NextResponse.json({error:"Gift animation not in demo allowlist"},{status:404});
 const upstream=await fetch(`https://nft.fragment.com/gift/${gift}.tgs`,{next:{revalidate:3600}});
 if(!upstream.ok)return NextResponse.json({error:"Animation unavailable upstream"},{status:502});
 return new NextResponse(await upstream.arrayBuffer(),{headers:{"Content-Type":"application/gzip","Cache-Control":"public, max-age=3600"}});
}