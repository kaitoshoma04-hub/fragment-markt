import {NextResponse} from "next/server";
export const revalidate=3600;
const API="https://api.changes.tg";
async function get(path:string){const r=await fetch(`${API}${path}`,{next:{revalidate:3600}});if(!r.ok)throw new Error(`Gift API ${path}: ${r.status}`);return r.json()}
function arr(v:any):any[]{if(Array.isArray(v))return v;if(v&&typeof v==="object")return Object.values(v);return []}
function str(v:any,fallback=""){return typeof v==="string"?v:fallback}
export async function GET(){
 try{
  const [giftList,ids,total,dates,auctions]=await Promise.all([
   get("/gifts"),get("/ids"),get("/total"),get("/dates"),get("/auctions")
  ]);
  const names=arr(giftList).map((x:any)=>typeof x==="string"?x:(x.name||x.gift||x.title||"")).filter(Boolean);
  const idMap:Record<string,string>= {};
  if(ids&&typeof ids==="object"&&!Array.isArray(ids))Object.assign(idMap,ids);
  const detailResults=await Promise.all(names.map(async(name:string)=>{
   try{
    const d=await get(`/gift/${encodeURIComponent(name)}`);
    const models=arr(d.models).map((m:any)=>({
      name:str(m.name||m.model),telegramName:str(m.telegramName||m.name||m.model),
      documentId:m.documentId??null,documentIds:arr(m.documentIds),
      rarity:m.rarity??null,rarityPermille:m.rarityPermille??null,
      originalRarity:m.originalRarity??null,crafted:!!m.crafted,
      rarityTier:m.rarityTier??null,customEmojiId:m.customEmojiId??null
    }));
    const id=d.id??d.giftId??Object.entries(idMap).find(([k,v])=>v===name)?.[0]??null;
    return {id:String(id??""),name:str(d.name,name),slug:name,models,
      backdrops:arr(d.backdrops).length,symbols:arr(d.symbols).length,
      releasedAt:d.releasedAt??null,upgradableAt:d.upgradableAt??null,
      upgradable:!!d.upgradable,modelCount:models.length,
      originalAnimation:`/api/gift-original/${encodeURIComponent(String(id??name))}`};
   }catch{return {id:"",name,slug:name,models:[],backdrops:0,symbols:0,releasedAt:null,upgradableAt:null,upgradable:false,modelCount:0,originalAnimation:""}}
  }));
  return NextResponse.json({source:"Gift Changes API",at:new Date().toISOString(),total,gifts:detailResults,auctions,dates});
 }catch(e){return NextResponse.json({error:"Gift catalog is temporarily unavailable",detail:String(e)}, {status:502})}
}