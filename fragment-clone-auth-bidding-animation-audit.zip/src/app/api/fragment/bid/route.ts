import {NextRequest,NextResponse} from "next/server";
import {assertSameOrigin,fragmentInit,fragmentRpc,getFragmentSession,setFragmentSession} from "@/lib/fragment-session";
export const runtime="nodejs";
const validType=new Set(["username","phone_number","collectible"]);
export async function POST(req:NextRequest){try{
 assertSameOrigin(req);
 const session=await getFragmentSession();if(!session?.stel_token)return NextResponse.json({error:"Authenticate with Fragment Telegram login first"},{status:401});
 if(!session.stel_ton_token||!session.wallet_address)return NextResponse.json({error:"Connect and verify your TON wallet with Fragment first"},{status:403});
 const body=await req.json();const type=String(body.type||""),username=String(body.username||"").trim(),bid=String(body.bid||"");
 if(!validType.has(type)||!username||username.length>128||/[\\r\\n]/.test(username))return NextResponse.json({error:"Invalid auction item"},{status:400});
 if(!/^(?:0|[1-9]\\d{0,8})(?:\\.\\d{1,9})?$/.test(bid)||Number(bid)<=0||Number(bid)>1000000)return NextResponse.json({error:"Bid must be a positive TON amount (max 1,000,000 TON)"},{status:400});
 const {hash,cookies}=await fragmentInit(session);
 await fragmentRpc(cookies,hash,{method:"updateAuction",type,username});
 const prepared=await fragmentRpc(cookies,hash,{method:"getBidLink",type,username,bid});
 const tx=prepared.data.transaction;
 if(!tx||!Array.isArray(tx.messages)||tx.messages.length<1||tx.messages.length>4)throw new Error("Fragment returned an invalid transaction");
 const validUntil=Number(tx.validUntil);if(!Number.isSafeInteger(validUntil)||validUntil<=Math.floor(Date.now()/1000)||validUntil>Math.floor(Date.now()/1000)+15*60)throw new Error("Fragment transaction has an invalid expiry");
 const messages=tx.messages.map((m:any)=>{const address=String(m.address||""),amount=String(m.amount||"");if(!/^(?:EQ|UQ|kQ|0:)[A-Za-z0-9_:+-]{20,100}$/.test(address)||!/^[1-9]\\d{0,19}$/.test(amount))throw new Error("Fragment returned an invalid TON message");if(m.payload!==undefined&&typeof m.payload!=="string")throw new Error("Invalid transaction payload");return {address,amount,...(m.payload?{payload:m.payload}:{})}});
 const total=messages.reduce((n,m)=>n+BigInt(m.amount),0n);
 const requested=BigInt(bid.replace(".","").padEnd(bid.split(".")[0].length+9,"0"));
 if(total>requested+10_000_000_000n)throw new Error("TON transaction total exceeds the bid by more than the 10 TON safety margin");
 const response=NextResponse.json({ok:true,source:"fragment.com",item:{type,username},bid,walletAddress:session.wallet_address,transaction:{validUntil,network:"-239",messages}});
 setFragmentSession(response,prepared.cookies);return response;
 }catch(e){return NextResponse.json({error:"Could not prepare Fragment bid",detail:String(e)},{status:502})}}
