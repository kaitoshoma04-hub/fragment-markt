import {NextRequest,NextResponse} from "next/server";
export const dynamic="force-dynamic";
const ORIGIN="https://fragment.com";
async function getHash(){
 const r=await fetch(ORIGIN+"/",{headers:{"User-Agent":"Mozilla/5.0 (compatible; FragmentClone/1.0)","Accept":"text/html"},cache:"no-store"});
 if(!r.ok)throw new Error(`Fragment homepage returned ${r.status}`);
 const html=await r.text();
 const patterns=[/["']apiUrl["']\s*:\s*["']\\?\/api\?hash=([a-f0-9]+)["']/i,/\/api\?hash=([a-f0-9]+)/i];
 for(const p of patterns){const m=html.match(p);if(m)return m[1]}
 throw new Error("Could not find Fragment's current API hash");
}
export async function GET(req:NextRequest){
 try{
  const q=req.nextUrl.searchParams.get("q")||"";
  const kind=req.nextUrl.searchParams.get("type")||"usernames";
  const offset=req.nextUrl.searchParams.get("offset_id")||"";
  if(!["usernames","numbers","collectibles"].includes(kind))return NextResponse.json({error:"Unsupported listing type"},{status:400});
  const hash=await getHash();
  const body=new URLSearchParams({method:"searchAuctions",type:kind,query:q});
  if(offset)body.set("offset_id",offset);
  const r=await fetch(`${ORIGIN}/api?hash=${hash}`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8","X-Requested-With":"XMLHttpRequest","X-Aj-Referer":ORIGIN+"/","User-Agent":"Mozilla/5.0 (compatible; FragmentClone/1.0)","Origin":ORIGIN,"Referer":ORIGIN+"/"},body:body.toString(),cache:"no-store"});
  const data=await r.json();
  if(!r.ok||data?.error)return NextResponse.json({error:data?.error||`Fragment API returned ${r.status}`},{status:r.status||502});
  return NextResponse.json({source:"fragment.com",type:kind,query:q,updatedAt:new Date().toISOString(),...data},{headers:{"Cache-Control":"no-store"}});
 }catch(e){return NextResponse.json({error:"Live Fragment data is currently unavailable",detail:String(e)},{status:502})}
}