import type { Metadata } from "next";
import "./globals.css";
import "./fragment-original.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Providers } from "./providers";
export const metadata: Metadata = { title: "Fragment — Digital collectibles marketplace", description: "Independent marketplace UI concept" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body><Providers><SiteHeader/>{children}<SiteFooter/></Providers></body></html>;
}