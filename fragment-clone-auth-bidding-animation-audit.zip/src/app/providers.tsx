 "use client";
import {TonConnectUIProvider} from "@tonconnect/ui-react";
export function Providers({children}:{children:React.ReactNode}) {
  const manifest = process.env.NEXT_PUBLIC_TONCONNECT_MANIFEST_URL || "https://YOUR_DOMAIN/tonconnect-manifest.json";
  return <TonConnectUIProvider manifestUrl={manifest}>{children}</TonConnectUIProvider>;
}