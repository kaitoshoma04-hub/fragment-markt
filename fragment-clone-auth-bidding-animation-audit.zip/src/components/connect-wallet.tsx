 "use client";
import {TonConnectButton,useTonAddress} from "@tonconnect/ui-react";
export function ConnectWallet(){const address=useTonAddress();return <div className="ton-connect-wrap"><TonConnectButton/><span className="wallet-state">{address?`Connected · ${address.slice(0,6)}…${address.slice(-4)}`:""}</span></div>}