 "use client";
import Link from "next/link";
import {useState} from "react";
import {Menu,X} from "lucide-react";
import {ConnectWallet} from "./connect-wallet";
import {TelegramLogin} from "./telegram-login";
import {FragmentWalletAuth} from "./fragment-wallet-auth";
export function SiteHeader(){
 const [open,setOpen]=useState(false),[telegram,setTelegram]=useState(false),[walletAuth,setWalletAuth]=useState(false);
 const links=[["Usernames","/usernames"],["Numbers","/numbers"],["Gifts","/gifts"],["Auctions","/auctions"],["Stars","/stars"],["Premium","/premium"],["Ads","/ads"]];
 return <>
 <header className="topbar"><div className="navwrap"><Link href="/" className="brand">◢ FRAGMENT</Link><nav className={open?"navlinks open":"navlinks"}>{links.map(([t,h])=><Link key={t} href={h} onClick={()=>setOpen(false)}>{t}</Link>)}</nav><div className="navright"><button className="telegram-connect" onClick={()=>setTelegram(true)}>➤ Connect Telegram</button><ConnectWallet/><button className="telegram-connect" onClick={()=>setWalletAuth(true)}>Verify TON</button><button className="mobilemenu" onClick={()=>setOpen(!open)} aria-label="Menu">{open?<X/>:<Menu/>}</button></div></div></header>
 {telegram&&<div className="modalshade" onMouseDown={e=>{if(e.target===e.currentTarget)setTelegram(false)}}><div className="authmodal"><button className="modalclose" onClick={()=>setTelegram(false)}>×</button><div className="modalbrand">➤　◢</div><h2>Log in to Fragment</h2><p>Use the Telegram account linked to your Fragment profile. The server verifies Telegram's signature and exchanges it for a Fragment session.</p><div className="telegram-widget"><TelegramLogin/></div></div></div>}
 {walletAuth&&<div className="modalshade" onMouseDown={e=>{if(e.target===e.currentTarget)setWalletAuth(false)}}><div className="authmodal"><button className="modalclose" onClick={()=>setWalletAuth(false)}>×</button><div className="modalbrand">◇　◢</div><h2>Connect Fragment wallet</h2><p>First log in with Telegram. Then request a Fragment TON proof and approve it in your wallet.</p><FragmentWalletAuth/></div></div>}
 </>;
}