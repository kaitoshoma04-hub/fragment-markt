 "use client";
import {useEffect,useMemo,useState} from "react";
import type {MouseEvent} from "react";
import DOMPurify from "isomorphic-dompurify";
import Link from "next/link";
import {FragmentTgsHydrator} from "./fragment-tgs-hydrator";
type Kind="usernames"|"numbers"|"collectibles";
export function FragmentLiveMarket({kind}:{kind:Kind}){
 const [q,setQ]=useState(""),[data,setData]=useState<any>(null),[loading,setLoading]=useState(false),[error,setError]=useState(""),[offset,setOffset]=useState("");
 const title=kind==="usernames"?"Usernames":kind==="numbers"?"Numbers":"Gifts";
 async function load(next=false){setLoading(true);setError("");try{const u=new URLSearchParams({type:kind,q});if(next&&offset)u.set("offset_id",offset);const r=await fetch(`/api/fragment/search?${u.toString()}`,{cache:"no-store"});const x=await r.json();if(!r.ok)throw new Error(x.detail||x.error||"Request failed");setData((old:any)=>next&&old?{...x,html:(old.html||"")+(x.html||""),body:(old.body||"")+(x.body||"")}:x);setOffset(x.next_offset||x.offset_id||"");}catch(e){setError(String(e))}finally{setLoading(false)}}
 useEffect(()=>{load(false)},[kind]);
 const markup=useMemo(()=>DOMPurify.sanitize(data?.html||data?.body||"",{USE_PROFILES:{html:true},ADD_ATTR:["class","data-*","target","rel"],FORBID_TAGS:["script","iframe","form","input","button"],FORBID_ATTR:["onclick","onload","onerror"]}),[data]);
 function intercept(e:MouseEvent<HTMLDivElement>){const a=(e.target as HTMLElement).closest("a");if(!a)return;const href=a.getAttribute("href")||"";let path=href;try{path=new URL(href,location.origin).pathname}catch{}const m=path.match(/^\/(username|number|gift|collectible)\/([^/?#]+)/);if(m){e.preventDefault();const t=m[1]==="number"?"phone_number":m[1]==="gift"||m[1]==="collectible"?"collectible":"username";location.href=`/auction/${t}/${encodeURIComponent(decodeURIComponent(m[2]))}`}}
 return <div className="fragment-live-market">
  <div className="fragment-market-toolbar"><div><div className="overline">FRAGMENT / LIVE MARKET</div><h1>{title}</h1><p>Live public listings and prices loaded from Fragment.</p></div><span className="live-source"><i/> fragment.com</span></div>
  <form className="fragment-search" onSubmit={e=>{e.preventDefault();setOffset("");load(false)}}><input value={q} onChange={e=>setQ(e.target.value)} placeholder={kind==="usernames"?"Enter a Telegram username":kind==="numbers"?"Enter a phone number":"+ Search gifts, models or numbers"}/><button disabled={loading}>{loading?"Loading…":"Search"}</button></form>
  {error&&<div className="fragment-error"><b>Live data unavailable</b><p>{error}</p><button onClick={()=>load(false)}>Retry</button></div>}
  {loading&&!data&&<div className="fragment-loading">Loading live Fragment listings…</div>}
  {data&&<div className="fragment-results"><div className="fragment-result-meta">Source: fragment.com · Updated {new Date(data.updatedAt).toLocaleTimeString()}</div><div className="fragment-original-html" onClick={intercept}><FragmentTgsHydrator html={markup}/></div>{!markup&&<div className="fragment-loading">Fragment returned no HTML results for this search.</div>}{offset&&<button className="fragment-more" disabled={loading} onClick={()=>load(true)}>Load more</button>}</div>}
  <p className="fragment-disclaimer">Prices and auction state are read from Fragment's public website response. This clone is read-only: it does not place bids, buy items or initiate TON transactions.</p>
 </div>
}