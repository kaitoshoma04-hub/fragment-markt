 "use client";
import {useEffect,useState} from "react";
import DOMPurify from "isomorphic-dompurify";
import {FragmentBidPanel} from "./fragment-bid-panel";
import {LottieGift} from "./lottie-gift";
export function FragmentAuctionDetail({type,slug}:{type:"username"|"phone_number"|"collectible";slug:string}){
 const [data,setData]=useState<any>(null),[error,setError]=useState(""),[loading,setLoading]=useState(true),[modal,setModal]=useState<"bid"|"how"|"history"|null>(null),[bid,setBid]=useState("");
 useEffect(()=>{let live=true;fetch(`/api/fragment/auction?type=${type}&username=${encodeURIComponent(slug)}`,{cache:"no-store"}).then(async r=>{const x=await r.json();if(!r.ok)throw new Error(x.detail||x.error||"Auction unavailable");if(live)setData(x)}).catch(e=>{if(live)setError(String(e))}).finally(()=>{if(live)setLoading(false)});return()=>{live=false}},[type,slug]);
 const html=DOMPurify.sanitize(data?.html||"",{USE_PROFILES:{html:true},ADD_ATTR:["class","data-*","target","rel"],FORBID_TAGS:["script","iframe","form","input","button"],FORBID_ATTR:["onclick","onload","onerror","style"]});
 const giftMatch=type==="collectible"?slug.match(/^([a-z]+)-(\d+)$/i):null;
 const title=type==="username"?"Collectible username":type==="phone_number"?"Anonymous number":"Telegram gift";
 return <section className="shell fragment-detail-page">
  <div className="fragment-detail-top"><a href={type==="username"?"/usernames":type==="phone_number"?"/numbers":"/gifts"}>‹ Back to {type==="username"?"Usernames":type==="phone_number"?"Numbers":"Gifts"}</a><span className="live-source"><i/> Live Fragment data</span></div>
  <div className="fragment-detail-layout">
   <div className="fragment-detail-art">{giftMatch?<><LottieGift src={`/api/fragment/gift-animation/${giftMatch[1]}/${giftMatch[2]}`}/><span className="gift-hashtag">#{giftMatch[2]}</span></>:<div className="detail-placeholder">{type==="username"?"＠":"✳"}</div>}</div>
   <div className="fragment-detail-info"><div className="overline">{title.toUpperCase()}</div><h1>{giftMatch?giftMatch[1].replace(/([a-z])([A-Z])/g,"$1 $2"):slug}</h1><p className="page-desc">{type==="collectible"?"Collectible Telegram gift":type==="username"?"Telegram collectible username":"Anonymous Telegram number"}</p>
    <div className="fragment-live-html">{loading?<div className="fragment-loading">Loading current auction state…</div>:error?<div className="fragment-error">{error}</div>:html?<div dangerouslySetInnerHTML={{__html:html}}/>:<div className="fragment-loading">Fragment returned no auction HTML for this asset.</div>}</div>
    <div className="fragment-detail-actions"><button onClick={()=>setModal("bid")}>Place a bid</button><button className="secondary" onClick={()=>setModal("how")}>How it works</button><button className="secondary" onClick={()=>setModal("history")}>History</button></div>
    <p className="fragment-disclaimer">Live state is requested from fragment.com. The clone does not sign transactions or place bids.</p>
   </div>
  </div>
  {modal==="bid"&&<FragmentBidPanel type={type} slug={slug} onClose={()=>setModal(null)}/>}
  {modal==="how"&&<div className="fragment-modal-shade" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null)}}><div className="fragment-modal"><button className="fragment-modal-x" onClick={()=>setModal(null)}>×</button><div className="overline">AUCTION GUIDE</div><h2>How auctions work</h2><p>Fragment creates a bid transaction using the current auction state. Your TON wallet then displays the destination and amount and asks you to approve. Only after on-chain confirmation should a bid be considered settled.</p><button onClick={()=>setModal(null)}>Got it</button></div></div>}
  {modal==="history"&&<div className="fragment-modal-shade" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(null)}}><div className="fragment-modal"><button className="fragment-modal-x" onClick={()=>setModal(null)}>×</button><div className="overline">ASSET HISTORY</div><h2>Ownership and bids</h2><p>History is shown only when returned by Fragment's current public page. This clone does not synthesize owner or bid records.</p><button onClick={()=>setModal(null)}>Close</button></div></div>}
 </section>
}