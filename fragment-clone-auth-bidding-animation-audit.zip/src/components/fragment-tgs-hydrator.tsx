 "use client";
import {useEffect,useRef} from "react";
import lottie,{AnimationItem} from "lottie-web";
import {ungzip} from "pako";
export function FragmentTgsHydrator({html}:{html:string}){
 const host=useRef<HTMLDivElement>(null);
 useEffect(()=>{const root=host.current;if(!root)return;let dead=false;const players:AnimationItem[]=[];
 const run=async()=>{const nodes=Array.from(root.querySelectorAll("picture.js-lottie, picture[data-multi-source]"));
 for(const node of nodes){if(dead)break;const pic=node as HTMLPictureElement;if(pic.dataset.cloneLottie==="1")continue;const source=pic.querySelector('source[type="application/x-tgsticker"]');const raw=source?.getAttribute("srcset")||source?.getAttribute("src")||"";const url=raw.split(",")[0].trim().split(/\s+/)[0];if(!url)continue;pic.dataset.cloneLottie="1";try{const r=await fetch(url);if(!r.ok)continue;const bytes=new Uint8Array(await r.arrayBuffer());let text:string;try{text=new TextDecoder().decode(ungzip(bytes))}catch{text=new TextDecoder().decode(bytes)}const data=JSON.parse(text);if(dead)break;const img=pic.querySelector("img");const wrap=document.createElement("div");wrap.className="fragment-tgs-player";pic.appendChild(wrap);if(img)img.style.opacity="0";const a=lottie.loadAnimation({container:wrap,renderer:"svg",loop:true,autoplay:true,animationData:data});players.push(a);const match=url.match(/([a-z0-9]+)-(\d+)\.tgs/i);if(match&&!pic.querySelector(".fragment-gift-hashtag")){const tag=document.createElement("span");tag.className="fragment-gift-hashtag";tag.textContent="#"+match[2];pic.appendChild(tag)}}catch(e){console.warn("Could not play original Fragment TGS",e)}}};
 run();return()=>{dead=true;players.forEach(p=>p.destroy())}},[html]);
 return <div ref={host} className="fragment-original-results" dangerouslySetInnerHTML={{__html:html}}/>;
}