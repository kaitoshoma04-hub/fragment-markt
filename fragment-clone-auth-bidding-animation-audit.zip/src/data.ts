export type Asset = {id:string; title:string; category:"Username"|"Gift"|"Number"; price:number; currency:string; owner:string; rarity:string; emoji:string; ends:number; description:string};
export const assets:Asset[] = [
 {id:"future",title:"@future",category:"Username",price:125,currency:"TON",owner:"f••••r",rarity:"Rare",emoji:"＠",ends:7200,description:"Короткое коллекционное имя пользователя."},
 {id:"crypto",title:"@crypto",category:"Username",price:250,currency:"TON",owner:"c••••o",rarity:"Epic",emoji:"＠",ends:18400,description:"Коллекционное имя пользователя."},
 {id:"diamond-008",title:"Diamond #008",category:"Gift",price:180,currency:"TON",owner:"0x•••8a",rarity:"Legendary",emoji:"💎",ends:3640,description:"Коллекционный подарок с редким визуальным оформлением."},
 {id:"plush-pepe",title:"Plush Pepe",category:"Gift",price:92,currency:"TON",owner:"0x•••2c",rarity:"Rare",emoji:"🐸",ends:9600,description:"Цифровой коллекционный подарок."},
 {id:"number-001",title:"+888 000 001",category:"Number",price:90,currency:"TON",owner:"0x•••1f",rarity:"Uncommon",emoji:"✳",ends:4800,description:"Коллекционный анонимный номер."},
 {id:"number-777",title:"+888 000 777",category:"Number",price:310,currency:"TON",owner:"0x•••77",rarity:"Epic",emoji:"✳",ends:22000,description:"Коллекционный номер с повторяющимися цифрами."}
];