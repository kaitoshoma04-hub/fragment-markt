# Fragment Clone — расширенная демонстрационная версия

Независимый проект, повторяющий структуру интерфейса Fragment по предоставленным скриншотам. Не является официальным сайтом.

## Запуск
- Node.js 20+
- `npm install`
- `cp .env.example .env.local`
- `npm run dev`

## Подключения

### TON Connect (реальное подключение кошелька)
1. Разместите проект на HTTPS-домене.
2. В `public/tonconnect-manifest.json` замените `YOUR_DOMAIN` на реальный домен и укажите URL PNG-иконки 180×180.
3. В `.env.local` задайте `NEXT_PUBLIC_TONCONNECT_MANIFEST_URL=https://ВАШ-ДОМЕН/tonconnect-manifest.json`.
4. Кнопка использует официальный `@tonconnect/ui-react`: кошельки, QR и Wallet Picker предоставляет сам TON Connect. Включены dark UI defaults SDK.
5. Не добавляйте приватные ключи/seed-фразы в приложение. Никаких транзакций проект сам не отправляет.

### Telegram Login (реальное подтверждение)
1. Создайте собственного бота через @BotFather.
2. Выполните `/setdomain` и укажите домен развёрнутого сайта.
3. Заполните `NEXT_PUBLIC_TELEGRAM_BOT_USERNAME`, `TELEGRAM_BOT_TOKEN` и длинный случайный `AUTH_SECRET` в `.env.local`.
4. Серверный endpoint `/api/auth/telegram` проверяет подпись Telegram Login Widget, ограничивает возраст auth_date и ставит HttpOnly cookie.
5. Для production добавьте полноценное управление сессиями, logout, CSRF/rate limits, privacy policy и хранение пользователей в БД. Не используйте токен бота на клиенте.

### Telegram Gifts / TGS
- `.tgs` — gzip-сжатый Lottie JSON; проигрывается через `pako` + `lottie-web`.
- Для демонстрационного Plush Pepe добавлен same-origin proxy `/api/gift-animation/PlushPepe-1`, который получает публичный TGS-файл с `nft.fragment.com` и кеширует его на час. Другие ID пока закрыты allowlist-ом.
- Для других подарков используйте проверенные публичные идентификаторы из каталога; не угадывайте URL. Источники форматов/каталогов указаны в README ниже.
- Можно положить разрешённые `.tgs` в `public/animations/` и передавать путь `/animations/name.tgs` в `LottieGift`.

## Страницы
`/`, `/usernames`, `/numbers`, `/gifts`, `/auctions`, `/stars`, `/premium`, `/ads`, `/search`, `/asset/[id]`.

## Важно
- Каталог, цены, лоты и ставки остаются демонстрационными: у Fragment нет публичного документированного API торгов, подключённого в этом проекте.
- Реальная торговля/ставки не подключены. Для production нужны собственный backend, индексатор TON, контракты/правила торгов, база данных и проверка транзакций.
- Telegram OAuth и TON Connect — разные потоки. Они не запрашивают пароль Telegram, seed-фразу или приватный ключ.
- Для полного production-профиля добавьте БД, сессии и права доступа.

## Источники документации и публичных форматов
- TON Connect: https://docs.ton.org/applications/ton-connect/get-started
- Telegram Login Widget: https://core.telegram.org/widgets/login/
- Telegram TGS format: https://core.telegram.org/api/stickers
- Публичный справочник Telegram collectible gifts: https://github.com/Nxrix/Telegram-Gifts
- Публичный TGS CDN-каталог (проверяйте актуальность и лицензию каждого файла): https://github.com/denzyve/cdn-telegram-gifts


## Live Telegram Gifts catalog (added)
- `/api/gift-catalog` loads the public Gift Changes API: `/gifts`, `/ids`, `/total`, `/dates`, and per-collection `/gift/:gift` metadata.
- `/gifts` displays live collection names/IDs, model counts, backdrops, release dates and upgradable state.
- Opening a collection displays its models, Telegram document IDs, rarity percentages, and crafted tiers.
- Selected model TGS animation is proxied from `/model/:gift/:model.tgs`; collection originals are loaded from `/original/:id.tgs`.
- `/auctions` reads `/auctions` and renders recorded historical Telegram gift primary-auction rounds. This is NOT a feed of current Fragment NFT secondary-market bids.
- API/CDN data is cached by Next.js (catalog 1 hour; TGS assets 24 hours; auctions 15 minutes).
- The visible site footer credits `@GiftChanges` as required by the API publisher.


## User-supplied Fragment source bundle
The archive `fragment-auction-main (3).zip` was inspected and preserved under `public/fragment-source/`.
- Contains `index.html`, `middlemen.html`, original CSS/JS files, TGS sticker helper, QR styling helper, TON Connect UI bundle, logo SVG sprite and font assets.
- `/reference` displays the supplied `index.html` source as-is in an iframe.
- The provided `index.html` is a standalone front-end mock: it creates 250 usernames and 150 anonymous numbers using `Math.random()`, and creates gift listing records from selected slugs with randomized counts/status/prices. These are not verified live Fragment marketplace records.
- `middlemen.html` is a static auction detail snapshot (example bid 8,888 TON, minimum 9,333 TON, countdown timestamp 2025-09-11T15:30:26Z), not a live auction feed.
- `main-aj.js` expects runtime `options.apiUrl` and uses authenticated POST method calls; the backend/API implementation and credentials are not included in this archive.
- Consequently the bundle is useful as a high-fidelity front-end reference and asset set, but it is not the complete production source/backend for Fragment.


## Original Fragment frontend migration (added)
- Original supplied `auction.css@94.css`, ProductSans fonts, Telemint SVG and source files are preserved in `public/fragment-original/` and `public/fragment-source/`.
- The live listing UI uses the original Fragment HTML fragments returned by its browser-facing RPC endpoint and sanitizes them before insertion; no iframe is used.
- `/usernames`, `/numbers`, `/gifts`, `/auctions` use the live read-only search proxy `/api/fragment/search`.
- `/auction/[type]/[slug]` requests current auction state using `updateAuction`.
- TGS assets embedded in original Fragment result HTML are hydrated with `lottie-web` + `pako`; gift number tags are derived from the NFT filename (`collection-number.tgs`).
- The `/api/fragment/*` routes are based on the unofficial, reverse-engineered browser endpoint and dynamic hash flow described by the community OpenAPI schema. Fragment does not publish a supported public developer API. The endpoint can change, rate-limit, or reject requests. If it fails, the UI shows an error rather than fake prices.
- Live market data is read-only. No `getBidLink`, `initOfferRequest`, payment, purchase, or bid transaction is called by this clone.
- The supplied `index.html` is a demo/fork with randomly generated offers, numbers, gifts, bids and owners. It is retained as reference only and is not used as a source of live prices.
- Telegram auth and TON wallet connect remain separate from Fragment's own session authentication. The clone does not claim that its login session is accepted by Fragment.


## Fragment account authentication, wallet proof and bidding (added)
- `POST /api/auth/fragment/telegram` verifies Telegram Login Widget HMAC using the official Login Widget derivation and calls Fragment's reverse-engineered `logIn` RPC.
- Fragment cookies (`stel_ssid`, `stel_token`, `stel_ton_token`, `stel_dt`) are stored only in an encrypted, HttpOnly, SameSite=Strict cookie. `AUTH_SECRET` must be a random secret of 32+ characters. Never expose it as a `NEXT_PUBLIC_` variable.
- `POST /api/auth/fragment/ton-challenge` requests Fragment's TON proof challenge. `FragmentWalletAuth` passes it through TON Connect `tonProof`; `POST /api/auth/fragment/ton-proof` forwards the signed wallet proof to Fragment's `checkTonProofAuth`.
- `POST /api/fragment/bid` requires both Fragment Telegram and TON wallet sessions, refreshes auction state, asks Fragment for `getBidLink`, validates transaction expiry and message structure, then returns the prepared TON Connect transaction.
- The user must explicitly click "Confirm and open TON wallet". The browser calls `sendTransaction`; the wallet shows the destination and amount and signs/broadcasts only after user approval. No seed phrase or private key is ever requested or handled by this app.
- The app does not mark bids as settled just because TON Connect returned a BoC. Production deployment should verify the resulting transaction on-chain and refresh Fragment auction state.
- Fragment's browser RPC is reverse-engineered and undocumented by Fragment. Its behavior, cookies, hash extraction and request shapes may change; it is not an official supported API. Test with a low-value bid on mainnet only after verifying every transaction field.
- The `audit:gifts` script fetches the live catalog and checks that every collection and model animation endpoint returns a parseable TGS/Lottie JSON. It also tries to extract current real NFT `.tgs` URLs from live Fragment collectible-search HTML. Run after deployment: `npm run audit:gifts -- https://your-domain.example`. It writes `gift-animation-audit.json`.
- This is an independent replica and is not affiliated with Telegram or Fragment.
